import { Route, Routes } from 'react-router-dom';
import './App.css';
import Layout from './Components/HeaderFooterLayout/Layout';
import Homepage from './Pages/Homepage';
import UserPage from './Pages/UserPage';
import PostPage from './Pages/PostPage';
import Dashboard from './Components/Dashboard';
import Authentication from './Pages/Authentication/Authentication';

function App() {
  return (
    <>
      <div className="App">
        <div className="Blur" style={{ top: '-18%', right: '0', position: 'fixed' }}></div>
        <div className="Blur" style={{ top: '36%', left: '-128px', position: 'fixed' }}></div>
        <div className="Blur" style={{ bottom: '-60px', right: '-160px', position: 'fixed' }}></div>
        <Routes>
          <Route path="/" element={<Layout />} >
            <Route index element={<Homepage />} />
            <Route path='/auth' element={<Authentication />} />
            <Route path='/dashboard' element={<Dashboard />} />
            <Route path='/user' element={<UserPage />} />
            <Route path='/post' element={<PostPage />} />
          </Route>
        </Routes>
      </div>
    </>
  );
}

export default App;
