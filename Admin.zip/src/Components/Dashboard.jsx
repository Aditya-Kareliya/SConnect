import React from 'react'
import { Link } from 'react-router-dom';

const Dashboard = () => {
  return (
    <>
      <div className="row d-flex justify-content-center" style={{ marginBottom: "250px", marginTop: "250px" }}>
        <div class="col-4 m-2 card bg-transparent border-2 border-primary " style={{ width: '300px' }}>
          <div class="card-body ">
            <Link to='/dashboard' className="text-decoration-none text-dark">
              <h5 class="card-title mb-4 cursor-pointer">
                <i class="fa-solid fa-gears"></i>
                <span className='ms-3'>Dashboard</span>
              </h5>
            </Link>
            <p class="card-text">Total Dashboard: <b className="ms-2">1</b></p>
          </div>
        </div>
        <div class="col-4 m-2 card bg-transparent border-2 border-primary" style={{ width: '300px' }}>
          <div class="card-body">
            <Link to='/user' className="text-decoration-none text-dark">
              <h5 class="card-title mb-4">
                <i class="fa-solid fa-user"></i>
                <span className='ms-3'>User</span>
              </h5>
            </Link>
            <p class="card-text">Total Users: <b className="ms-2">5</b></p>
          </div>
        </div>
        <div class="col-4 m-2 card bg-transparent border-2 border-primary" style={{ width: '300px' }}>
          <div class="card-body">
            <Link to='/post' className="text-decoration-none text-dark">
              <h5 class="card-title mb-4">
                <i class="fa-brands fa-slack"></i>
                <span className='ms-3'>Post</span>
              </h5>
            </Link>
            <p class="card-text">Total Posts: <b className="ms-2">10</b></p>
          </div>
        </div>
      </div>
    </>
  )
}

export default Dashboard