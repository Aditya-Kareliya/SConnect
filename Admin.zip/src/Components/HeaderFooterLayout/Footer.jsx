import React from 'react'
import { Link } from 'react-router-dom'
import Logo from '../../Assets/Images/logo.png'

const Footer = () => {
  return (
    <>
      <div class="container">
        <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
          <div class="col-md-4 d-flex align-items-center">
            <img src={Logo} alt="SConnect-Logo" height={"20px"} className='me-3' />
            <span class="mb-3 mb-md-0 text-body-secondary">&copy; Aditya Kareliya </span>
          </div>
          <ul class="nav col-md-4 justify-content-end list-unstyled d-flex">
            <li class="ms-3"><Link class="text-body-secondary" to="https://www.facebook.com/login/"><i class="fa-brands fa-facebook"></i></Link></li>
            <li class="ms-3"><Link class="text-body-secondary" to="https://www.instagram.com/accounts/login/"><i class="fa-brands fa-instagram"></i></Link></li>
            <li class="ms-3"><Link class="text-body-secondary" to="https://www.linkedin.com/login"><i class="fa-brands fa-linkedin-in"></i></Link></li>
          </ul>
        </footer>
      </div>
    </>
  )
}

export default Footer