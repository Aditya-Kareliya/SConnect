import React from 'react'

const PostPage = () => {
  return (
    <div>PostPage</div>
  )
}

export default PostPage