import React from 'react'
import './Authentication.css'
import Logo from '../../Assets/Images/logo.png'

const Authentication = () => {
    return (
        <div className="Authentication">
            <div className="AuthenticationLeftSide">
                <img src={Logo} alt="Logo" />
                <div className="WebName">
                    <h1>Social Connect</h1>
                    <h5>Discover your tribe.</h5>
                </div>
            </div>
            <Login />
        </div>
    )
}

const Login = () => {
    return (
        <>
            <div className="AuthenticationRightSide">
                <form action="" className="InfoForm AuthForm">
                    <h3>Login</h3>
                    <div>
                        <input type="email" placeholder='@username ( example@darshan.ac.in )' className='InfoInput' name='userName' />
                    </div>
                    <div>
                        <input type="password" placeholder='password' className='InfoInput' name='password' />
                    </div>
                    <button className="Button InfoButton" type='submit'>Login</button>
                </form>
            </div>
        </>
    )
}

export default Authentication