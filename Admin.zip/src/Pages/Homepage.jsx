import React from 'react'
import Dashboard from '../Components/Dashboard'

const Homepage = () => {
    return (
        <>
            <Dashboard />
        </>
    )
}

export default Homepage