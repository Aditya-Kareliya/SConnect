import React, { useState } from 'react'
import UserandPostModel from '../Components/UserAndPostModel/UserandPostModel'

const UserPage = () => {
  const [modelOpened, setModelOpened] = useState(false)
  return (
    <>
      <div className="row g-3">
        <div className="col-9 mb-4" style={{ marginTop: "50px", marginLeft: "150px" }}>
          <h1 className='mb-4'>Add User</h1>
        </div>
        <div className="col mb-4 btn btn-success align-items-center justify-content-center d-flex" style={{ marginTop: "50px", marginRight: "150px" }} onClick={() => {
          setModelOpened(true)
        }}>
          <i class="fa-solid fa-user-plus"></i>
          <UserandPostModel modelOpened={modelOpened} setModelOpened={setModelOpened} />
        </div>
      </div>
      <table class="container table table-striped table-bordered table-hover " style={{ margin: "20px 150px 280px 150px" }}>
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">First</th>
            <th scope="col">Last</th>
            <th scope="col">Handle</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td>Otto</td>
            <td>@mdo</td>
          </tr>
          <tr>
            <th scope="row">2</th>
            <td>Jacob</td>
            <td>Thornton</td>
            <td>@fat</td>
          </tr>
          <tr>
            <th scope="row">3</th>
            <td colspan="2">Larry the Bird</td>
            <td>@twitter</td>
          </tr>
        </tbody>
      </table>
    </>
  )
}

export default UserPage