import React, { StrictMode } from "react";
import ReactDOM from "react-dom";
import App from "./App";

const rootElement = document.getElementById('root');
const root = ReactDOM.createRoot(rootElement);

root.render(<App />);

// Ensure the container exists
const container = document.getElementById('root');
if (!container) {
  throw new Error('Root container not found. Check your public/index.html file.');
}

ReactDOM.render(
    <StrictMode>
      <App />
    </StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
