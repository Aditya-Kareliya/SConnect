import { Routes, Route } from 'react-router-dom';
import Authentication from '../Pages/Authentication/Authentication';
import HomePage from '../Pages/HomePage/HomePage';
import ProfilePage from '../Pages/ProfilePage/ProfilePage';

const AppRoutes = () => {
    return (
        <Routes>
            <Route path="/" element={<Authentication />} >
            <Route path="/auth" element={<Authentication />} />
            <Route path="/home" element={<HomePage />} />
            <Route path="/profile" element={<ProfilePage />} />
            </Route>
        </Routes>
    );
};

export default AppRoutes;