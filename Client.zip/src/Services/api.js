import axios from 'axios'

const API = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5001',
  withCredentials: true
})

// Add request interceptor
API.interceptors.request.use((config) => {
  const token = localStorage.getItem('socialMediaToken')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

export const authAPI = {
  signup: (userData) => API.post(`${process.env.REACT_APP_API_URL}/auth/signup`, userData),
  verifyOTP: (otpData) => API.post(`${process.env.REACT_APP_API_URL}/auth/verify-otp`, otpData),
  login: (credentials) => API.post(`${process.env.REACT_APP_API_URL}/auth/login`, credentials)
}

export const userAPI = {
  getProfile: (userId) => API.get(`/user/${userId}`),
  updateProfile: (userId, data) => API.put(`/user/${userId}`, data)
}

export const postAPI = {
  createPost: (postData) => API.post('/post', postData),
  getTimelinePosts: (userId) => API.get(`/post/${userId}/timeline`)
}