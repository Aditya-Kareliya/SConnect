import { BrowserRouter } from 'react-router-dom'
import { AuthProvider } from './Context/AuthContext'
import AppRoutes from './Routes/Routes';

import './App.css'

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <div className="App">
          <div className="Blur" style={{ top: '-18%', right: '0' }}></div>
          <div className="Blur" style={{ top: '36%', left: '-128px' }}></div>
          <div className="Blur" style={{ bottom: '-60px', right: '-160px' }}></div>
          <AppRoutes />
        </div>
      </AuthProvider>
    </BrowserRouter>
  )
}

export default App