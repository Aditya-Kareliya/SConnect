import PostImage1 from '../Assets/img/postPic1.jpg'
import PostImage2 from '../Assets/img/postPic2.jpg'
import PostImage3 from '../Assets/img/postPic3.jpg'

export const PostsData = [
    {
        img: PostImage1,
        name: "Aditya",
        desc: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nihil repellat, sunt deserunt eos quaerat consequatur soluta labore velit, deleniti, necessitatibus ipsum cumque ut. Praesentium voluptas temporibus, voluptates velit placeat tempore!",
        likes: 2300,
        liked: true
    },
    {
        img: PostImage2,
        name: "Guru",
        desc: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nihil repellat, sunt deserunt eos quaerat consequatur soluta labore velit, deleniti, necessitatibus ipsum cumque ut. Praesentium voluptas temporibus, voluptates velit placeat tempore!",
        likes: 200,
        liked: false
    },
    {
        img: PostImage3,
        name: "Raj",
        desc: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nihil repellat, sunt deserunt eos quaerat consequatur soluta labore velit, deleniti, necessitatibus ipsum cumque ut. Praesentium voluptas temporibus, voluptates velit placeat tempore!",
        likes: 2100,
        liked: true
    },
]