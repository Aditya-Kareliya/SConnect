import img1 from '../Assets/img/img1.png'
import img2 from '../Assets/img/img2.png'
import img3 from '../Assets/img/img3.png'
import img4 from '../Assets/img/img4.jpg'

export const Followers = [
    {
        name: "Aditya Kareliya",
        userName: "adityakareliya",
        img: img1
    },
    {
        name: "Guru Bhalodiya",
        userName: "gurubhalodiya",
        img: img2
    },
    {
        name: "Selvi Makvana",
        userName: "selvimakwana",
        img: img3
    },
    {
        name: "Priya Kalola",
        userName: "priyakalola",
        img: img4
    },
]