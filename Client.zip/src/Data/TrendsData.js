export const TrendsData = [
    {
        name: "Minions",
        shares: 97
    },
    {
        name: "Avengers",
        shares: 80.5
    },
    {
        name: "Aditya",
        shares: 75.5
    },
    {
        name: "Akshat",
        shares: 72
    },
    {
        name: "Guru",
        shares: 21
    },
    {
        name: "Raj",
        shares: 42
    },
]