import React from 'react'
import './ProfilePage.css'
import ProfileLeftSide from '../../Components/ProfileLeftSide/ProfileLeftSide'
import ProfileCard from '../../Components/ProfileCard/ProfileCard'
import MiddleContent from '../../Components/MiddleContent/MiddleContent'
import RightSideContent from '../../Components/RightSideContent/RightSideContent'

const ProfilePage = () => {
    return (
        <div className="ProfilePage">
            <ProfileLeftSide />
            <div className="ProFileCenter">
                <ProfileCard />
                <MiddleContent />
            </div>
            <RightSideContent />
        </div>
    )
}

export default ProfilePage