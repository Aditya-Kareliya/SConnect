import React from 'react'
import "./HomePage.css";
import LeftSideContent from '../../Components/LeftSideContent/LeftSideContent';
import MiddleContent from '../../Components/MiddleContent/MiddleContent';
import RightSideContent from '../../Components/RightSideContent/RightSideContent';

const HomePage = () => {
  return (
    <div className="Home">
      <LeftSideContent />
      <MiddleContent />
      <RightSideContent />
    </div>
  )
}

export default HomePage