import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { authAPI } from '../../Services/api'
import OtpVerification from '../../Components/OtpVerification/OtpVerification'
import './Authentication.css'
import Logo from '../../Assets/img/logo.png'

const Authentication = () => {
  const [isSignUp, setIsSignUp] = useState(false)
  const [showOtp, setShowOtp] = useState(false)
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    lastName: ''
  })
  const [errors, setErrors] = useState({})
  const navigate = useNavigate()

  const validateForm = () => {
    const newErrors = {}
    
    // if (!formData.email.endsWith('@darshan.ac.in')) {
    //   newErrors.email = 'Only Darshan University emails allowed'
    // }
    
    if (isSignUp) {
      if (!formData.firstName) newErrors.firstName = 'First name required'
      if (!formData.lastName) newErrors.lastName = 'Last name required'
      if (formData.password.length < 6) newErrors.password = 'Password must be at least 6 characters'
      if (formData.password !== formData.confirmPassword) newErrors.confirmPassword = 'Passwords do not match'
    }
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!validateForm()) return

    try {
      if (isSignUp) {
        const { data } = await authAPI.signup(formData)
        setShowOtp(true)
      } else {
        const { data } = await authAPI.login({
          email: formData.email,
          password: formData.password
        })
        localStorage.setItem('socialMediaToken', data.token)
        localStorage.setItem('user', JSON.stringify(data.user))
        navigate('/home')
      }
    } catch (error) {
      setErrors({ apiError: error.response?.data?.message || 'Something went wrong' })
    }
  }

  const handleOtpVerification = async (otp) => {
    try {
      await authAPI.verifyOTP({
        email: formData.email,
        verificationCode: otp
      })
      setShowOtp(false)
      setIsSignUp(false)
      setErrors({ success: 'Verification successful! Please login' })
    } catch (error) {
      setErrors({ otpError: error.response?.data?.message || 'Invalid OTP' })
    }
  }

  return (
    <div className="Authentication">
      <div className="AuthenticationLeftSide">
        <img src={Logo} alt="Logo" />
        <div className="WebName">
          <h1>Social Connect</h1>
          <h5>Discover your tribe.</h5>
        </div>
      </div>

      <div className="AuthenticationRightSide">
        {showOtp ? (
          <OtpVerification 
            email={formData.email}
            onVerify={handleOtpVerification}
            error={errors.otpError}
          />
        ) : (
          <form className="InfoForm AuthForm" onSubmit={handleSubmit}>
            <h3>{isSignUp ? "Sign Up" : "Login"}</h3>

            {errors.apiError && <div className="error">{errors.apiError}</div>}
            {errors.success && <div className="success">{errors.success}</div>}

            {isSignUp && (
              <>
                <div>
                  <input
                    type="text"
                    placeholder='First Name'
                    name='firstName'
                    value={formData.firstName}
                    onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                  />
                  {errors.firstName && <span className="error-text">{errors.firstName}</span>}
                </div>
                <div>
                  <input
                    type="text"
                    placeholder='Last Name'
                    name='lastName'
                    value={formData.lastName}
                    onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                  />
                  {errors.lastName && <span className="error-text">{errors.lastName}</span>}
                </div>
              </>
            )}

            <div>
              <input
                type="email"
                placeholder='example@darshan.ac.in'
                name='email'
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
              />
              {errors.email && <span className="error-text">{errors.email}</span>}
            </div>

            <div>
              <input
                type="password"
                placeholder='Password'
                name='password'
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
              />
              {errors.password && <span className="error-text">{errors.password}</span>}
            </div>

            {isSignUp && (
              <div>
                <input
                  type="password"
                  placeholder='Confirm Password'
                  name='confirmPassword'
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                />
                {errors.confirmPassword && <span className="error-text">{errors.confirmPassword}</span>}
              </div>
            )}

            <div className="toggle-auth">
              <span onClick={() => setIsSignUp(!isSignUp)}>
                {isSignUp 
                  ? "Already have an account? Login" 
                  : "Don't have an account? Sign Up"}
              </span>
            </div>

            <button type="submit" className="Button InfoButton">
              {isSignUp ? "Sign Up" : "Login"}
            </button>
          </form>
        )}
      </div>
    </div>
  )
}

export default Authentication