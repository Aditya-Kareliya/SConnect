import React from 'react'
import './Post.css'
import Comment from '../../Assets/img/comment.png'
import Share from '../../Assets/img/share.png'
import Like from '../../Assets/img/like.png'
import NotLike from '../../Assets/img/notlike.png'

const Post = ({ data }) => {
    return (
        <div className="Post">
            <img src={data.img} alt="PostImage" />
            <div className="PostReactions">
                <img src={data.liked ? Like : NotLike} alt="Likes" />
                <img src={Comment} alt="Comment" />
                <img src={Share} alt="Share" />
            </div>
            <span style={{ color: 'var(--gray)', fontSize: '20px' }}>{data.likes} Likes</span>
            <div className="Detail">
                <span><b>{data.name}</b></span>
                <span> {data.desc}</span>
            </div>
        </div>
    )
}

export default Post