import React from 'react'
import { Modal, useMantineTheme } from '@mantine/core'
import '../../Pages/Authentication/Authentication.css'

const ProfileModel = ({ modelOpened, setModelOpened }) => {
    const theme = useMantineTheme()
    return (
        <div className="ProfileModel">
            <Modal
                overlayColor={
                    theme.colorScheme === 'dark'
                        ? theme.colors.dark[9]
                        : theme.colors.gray[2]
                }
                overlayOpacity={0.55}
                overlayBlur={3}
                onClose={() => { setModelOpened(false) }}
                opened={modelOpened}
                size='55%'
            >
                <form action="" className="InfoForm">
                    <h3>Your Info</h3>
                    <div>
                        <input type="text" placeholder='First Name' className='InfoInput' name='firstName' />
                        <input type="text" placeholder='Last Name' className='InfoInput' name='lastName' />
                    </div>
                    <div>
                        <input type="text" placeholder='Works At' className='InfoInput' name='worksAt' />
                    </div>
                    <div>
                        <input type="text" placeholder='Lives In' className='InfoInput' name='LivesIn' />
                        <input type="text" placeholder='Country' className='InfoInput' name='country' />
                    </div>
                    <div>
                        <input type="text" placeholder='Relationship Status' className='InfoInput' name='relationshipStatus' />
                    </div>
                    <div>
                        <span style={{ marginTop: '10px' }}>Profile Image</span>
                        <input type="file" name='profileImage' className='InfoInput' style={{ padding: '10px', alignSelf: 'center', marginTop: '15px' }} />
                    </div>
                    <div>
                        <span style={{ marginTop: '10px' }}>Cover Image</span>
                        <input type="file" name='coverImage' className='InfoInput' style={{ padding: '10px', alignSelf: 'center', marginTop: '20px' }} />
                    </div>
                    <button className="Button InfoButton" style={{ margin: '50px 50px 30px 0px' }}>Update</button>
                </form>
            </Modal>
        </div>
    )
}

export default ProfileModel