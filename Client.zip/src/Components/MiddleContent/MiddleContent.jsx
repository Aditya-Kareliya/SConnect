import React from 'react'
import './MiddleContent.css'
import PostShare from '../PostShare/PostShare'
import Posts from '../Posts/Posts'

const MiddleContent = () => {
    return (
        <div className="MiddleContent">
            <PostShare />
            <Posts />
        </div>
    )
}

export default MiddleContent