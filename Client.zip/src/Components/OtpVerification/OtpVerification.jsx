import { useState, useRef } from "react";

const OtpVerification = () => {
    const [otp, setOtp] = useState(["", "", "", "", "", ""]); // State to store OTP
    const [message, setMessage] = useState(""); // Message for validation or success
    const [resendDisabled, setResendDisabled] = useState(false); // Disable resend for 60 seconds
    const inputRefs = useRef([]); // To manage focus on inputs

    const handleChange = (e, index) => {
        const { value } = e.target;
        const newOtp = [...otp];

        // Allow only digits
        if (!/^[0-9]$/.test(value) && value !== "") return;

        newOtp[index] = value; // Update the specific index
        setOtp(newOtp);

        // Focus the next input automatically
        if (value && index < otp.length - 1) {
            inputRefs.current[index + 1].focus();
        }
    };

    const handleKeyDown = (e, index) => {
        // Handle backspace to move focus back
        if (e.key === "Backspace" && otp[index] === "" && index > 0) {
            inputRefs.current[index - 1].focus();
        }
    };

    const handleSubmit = () => {
        if (otp.join("").length === 6) {
            // Call API to verify OTP
            setMessage("OTP Verified Successfully!");
            console.log("Submitted OTP:", otp.join(""));
            
        } else {
            setMessage("Please enter all 6 digits.");
        }
    };

    const handleResend = () => {
        setResendDisabled(true);
        setMessage("OTP resent to your email.");
        // Call API to resend OTP
        setTimeout(() => setResendDisabled(false), 60000); // Enable after 60 seconds
    };

    return (
        <div className="AuthenticationRightSide">
            <form action="" className="InfoForm AuthForm">
                <h2>Verify Your Email</h2>
                <p>Enter the 6-digit OTP sent to your email address.</p>
                <div>
                    <input type="email" placeholder='@username ( example@darshan.ac.in )' className='InfoInput' name='userName' />
                </div>
                <div className='OtpInput'>
                    {otp.map((digit, index) => (
                        <input
                            key={index}
                            type="text"
                            maxLength="1"
                            value={digit}
                            onChange={(e) => handleChange(e, index)}
                            onKeyDown={(e) => handleKeyDown(e, index)}
                            ref={(el) => (inputRefs.current[index] = el)}
                        />
                    ))}
                </div>
                <button onClick={handleSubmit} className="Button InfoButton">Submit</button>
                <button className="Button" onClick={handleResend} disabled={resendDisabled} style={{ padding: '10px' }}>Resend OTP</button>
                {message && <p style={{ marginTop: "20px", color: "green" }}>{message}</p>}
            </form>
        </div>
    );
};

export default OtpVerification;