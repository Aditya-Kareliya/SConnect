import React from 'react'
import './TrendsCard.css'
import { TrendsData } from '../../Data/TrendsData'

const TrendsCard = () => {
    return (
        <div className="TrendsCard">
            <h3>Trends For You</h3>
            {
                TrendsData.map((trend) => {
                    return (
                        <div className="Trend">
                            <span> #{trend.name} </span>
                            <span> {trend.shares}k Shares </span>
                        </div>
                    )
                })
            }
        </div>
    )
}

export default TrendsCard