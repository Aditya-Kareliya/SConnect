import React, { useState } from 'react'
import './RightSideContent.css'
import Home from '../../Assets/img/home.png'
import Notifiaction from '../../Assets/img/noti.png'
import Comment from '../../Assets/img/comment.png'
import { UilSetting } from '@iconscout/react-unicons'
import TrendsCard from '../Trendscard/TrendsCard'
import ShareModel from '../ShareModel/Sharemodel'



const RightSideContent = () => {
    const [modelOpened, setModelOpened] = useState(false)
    return (
        <div className="RightSideContent">
            <div className="NavbarIcons">
                <img src={Home} alt="HomeIcon" />
                <UilSetting />
                <img src={Notifiaction} alt="NotificationIcon" />
                <img src={Comment} alt="CommentIcon" />
            </div>
            <TrendsCard />
            <button className="Button RightSideContentButton" onClick={() => { setModelOpened(true) }}>Share</button>
            <ShareModel modelOpened={modelOpened} setModelOpened={setModelOpened} />
        </div>
    )
}

export default RightSideContent