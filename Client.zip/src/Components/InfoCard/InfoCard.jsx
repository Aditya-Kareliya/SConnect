import React from 'react'
import './InfoCard.css'
import { UilPen } from '@iconscout/react-unicons'
import { useState } from 'react'
import ProfileModel from '../ProfileModel/ProfileModel'

const InfoCard = () => {
    const [modelOpened, setModelOpened] = useState(false)

    return (
        <div className="InfoCard">
            <div className="InfoHead">
                <h4>Your Info</h4>
                <div style={{marginLeft:'100px', marginBottom:'10px'}}>
                <UilPen width='32px' height='19px' onClick={() => { setModelOpened(true) }} />
                </div>
                <ProfileModel modelOpened={modelOpened} setModelOpened={setModelOpened} />
            </div>
            <div className="Info">
                <span>
                    <b>Status </b>
                </span>
                <span>in Relationship</span>
            </div>
            <div className="Info">
                <span>
                    <b>Lives In </b>
                </span>
                <span>Rajkot</span>
            </div>
            <div className="Info">
                <span>
                    <b>Works It </b>
                </span>
                <span>Darshan University</span>
            </div>
            <button className="Button LogoutButton">Logout</button>
        </div>
    )
}

export default InfoCard