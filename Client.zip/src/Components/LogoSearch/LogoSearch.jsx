import React from 'react'
import './LogoSearch.css'
import Logo from '../../Assets/img/logo.png'
import { UilSearch } from '@iconscout/react-unicons'

const LogoSearch = () => {
    return (
        <div className="LogoSearch">
            <img src={Logo} alt="Logo" srcset="" />
            <div className="Search">
                <input type="text" placeholder='#Explore' />
                <div className="SearchIcon">
                    <UilSearch />
                </div>
            </div>
        </div>
    )
}

export default LogoSearch