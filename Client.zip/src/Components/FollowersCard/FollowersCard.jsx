import React from 'react'
import './FollowersCard.css'
import { Followers } from '../../Data/FollowersData'

const FollowersCard = () => {
  return (
    <div className="FollowersCard">
      <h5>Who is Following You</h5>
      {
        Followers.map((Followers, id) => {
          return (
            <div className="Followers">
              <div>
                <img src={Followers.img} alt="FollowerImage" className='FollowerImage' />
                <div className="name">
                  <span> {Followers.name} </span>
                  <span> @{Followers.userName} </span>
                </div>
              </div>
              <button className='Button FollowerCardButton'>Follow</button>
            </div>
          )
        })
      }
    <span></span>
    </div>
  )
}

export default FollowersCard