import React from 'react'
import './ProfileCard.css'
import CoverImage from '../../Assets/img/cover.jpg'
import ProfileImage from '../../Assets/img/profileImg.jpg'


const ProfileCard = () => {
    const PROFILEPAGE = true;
    return (
        <div className="ProfileCard">
            <div className="ProfileImages">
                <img src={CoverImage} alt="Coverimage" />
                <img src={ProfileImage} alt="Profileimage" />
            </div>

            <div className="ProfileName">
                <span>Aditya Kareliya</span>
                <span>UI/UX Designer</span>
            </div>

            <div className="FollowStatus">
                <hr />
                <div>
                    <div className="Follow">
                        <span>6,890</span>
                        <span>Followings</span>
                    </div>
                    <div className="vl"></div>
                    <div className="Follow">
                        <span>1</span>
                        <span>Followers</span>
                    </div>
                    {
                        PROFILEPAGE &&
                        <>
                            <div className="vl"></div>
                            <div className="Follow">
                                <span>3</span>
                                <span>Posts</span>
                            </div>
                        </>
                    }
                </div>
                <hr />
            </div>
            {
                PROFILEPAGE ? '' : <span>My Profile</span>
            }
        </div>
    )
}

export default ProfileCard