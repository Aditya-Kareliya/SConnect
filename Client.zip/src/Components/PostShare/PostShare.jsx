import React, { useRef, useState } from 'react'
import ProfileImage from '../../Assets/img/profileImg.jpg'
import './PostShare.css'
import { UilScenery, UilPlayCircle, UilLocationPoint, UilTimes } from '@iconscout/react-unicons'

const PostShare = () => {

    const [image, setImage] = useState(null)
    const imageReference = useRef()

    return (
        <div className="PostShare">
            <img src={ProfileImage} alt="ProfileImage" />
            <div>
                <input type="text" placeholder="What's Hepnning" />
                <div className="PostOptions">
                    <div className="Option" style={{ color: "var(--photo)", border: "2px solid var(--photo)", borderRadius: "10px" }} onClick={() => imageReference.current.click()}>
                        <UilScenery />Photo
                    </div>
                    <div className="Option" style={{ color: "var(--video)", border: "2px solid var(--video)", borderRadius: "10px" }} onClick={() => imageReference.current.click()}>
                        <UilPlayCircle />Video
                    </div>
                    <div className="Option" style={{ color: "var(--location)", border: "2px solid var(--location)", borderRadius: "10px" }} onClick={() => imageReference.current.click()}>
                        <UilLocationPoint />Location
                    </div>
                    {/* <div className="Option" style={{ color: "var(--shedule)", border: "2px solid var(--shedule)", borderRadius: "10px" }} onClick={() => imageReference.current.click()}>
                        <UilSchedule />Shedule
                    </div> */}
                    <button className="Button PostShareButton">
                        Share
                    </button>
                    <div style={{ display: 'none' }}>
                        <input type="file" name="myImage" ref={imageReference} onChange={(event) => {
                            if (event.target.files && event.target.files[0]) {
                                let img = event.target.files[0]
                                setImage({
                                    image: URL.createObjectURL(img)
                                })
                            }
                        }} />
                    </div>
                </div>
                {
                    image && <div className="PreviewImage">
                        <UilTimes onClick={() => { setImage(null) }} />
                        <img src={image.image} alt='showImage' />
                    </div>
                }
            </div>
        </div>
    )
}

export default PostShare