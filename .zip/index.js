import express from 'express'
import bodyParser from 'body-parser'
import dotenv from 'dotenv'
import cors from 'cors'
import morgan from 'morgan'
import helmet from 'helmet'

dotenv.config()
const PORT = process.env.PORT || 5001

// Routes
const app = express()
import AuthenticationRoute from './Routes/AuthRoute.js'
import UserRoute from './Routes/UserRoute.js';
import PostRoute from './Routes/PostRoute.js'
import connectDB from './Config/Database.js'

// Database connection
connectDB()

// Middleware
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:3000',
  credentials: true
}));

app.use(helmet()) 
app.use(morgan('dev'))
app.use(express.json({ limit: '30mb' }))
app.use(express.urlencoded({ extended: true, limit: '30mb' }))
app.use(bodyParser.json({ extended: true }))
app.use(bodyParser.urlencoded({ extended: true }))

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).json({ message: 'Something broke!', error: err.message })
})

// Usages of Route 
app.use('/auth', AuthenticationRoute)
app.use('/user', UserRoute)
app.use('/post', PostRoute)


// Server Start
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});