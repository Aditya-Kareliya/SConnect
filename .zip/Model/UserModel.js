import mongoose from "mongoose";

const UserSchema = new mongoose.Schema(
    {
        email: { type: String, required: true, unique: true },
        password: { type: String, required: true },
        firstName: { type: String, required: true },
        lastName: { type: String, required: true },
        isAdmin: { type: Boolean, default: false },
        profilePicture: { type: String },
        coverPicture: { type: String },
        about: { type: String },
        livesIn: { type: String },
        worksAt: { type: String },
        relationship: { type: String },
        followers: { type: Array, default: [] },
        following: { type: Array, default: [] },
        // varification through email
        isUserVerified: { type: Boolean, default: false },
        verificationCode: { type: String },
        verificationExpires: { type: Date },
    },
    { timestamps: true }
);

const UserModel = mongoose.model("User", UserSchema);
export default UserModel;
