import { Verification_Email_Template, Welcome_Email_Template } from '../lib/EmailTemplate.js';
import { transporter } from './EmailVarification.js'

export const sendVerificationEmail = async (email, varificartionCode) => {
    try {
        const response = await transporter.sendMail({
            from: '"SConnect 👋" sconnect200@gmail.com', // sender address
            to: email, // list of receivers
            subject: "Verify Your Email", // Subject line
            text: "Verify Your Email", // plain text body
            html: Verification_Email_Template.replace("{verificationCode}", varificartionCode)
        })
        console.log("Email Sent Successfully", response);
    } catch (error) {
        console.log("Error sending email:", error.message);
    }
}

export const welcomeEmail = async (email, firstName) => {
    try {
        const response = await transporter.sendMail({
            from: '"SConnect 👋" sconnect200@gmail.com', // sender address
            to: email, // list of receivers
            subject: "Welcome Email", // Subject line
            text: "Welcome Email", // plain text body
            html: Welcome_Email_Template.replace("{name}", firstName)
        })
        console.log("Email Sent Successfully", response);
    } catch (error) {
        console.log("Error Sending Welcome Email", error.message);
    }
}