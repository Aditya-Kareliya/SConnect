import express from "express";
import { createPost, deletePost, getPost, getTimelinePost, likeAndDislikePost, updatePost } from "../Controller/PostController.js";
const router = express.Router()

router.post('/', createPost)
router.get('/:id', getPost)
router.put('/:id', updatePost)
router.delete('/:id', deletePost)
router.put('/:id/likeanddislike', likeAndDislikePost)
router.get('/:id/timeline', getTimelinePost)

export default router