import { sendVerificationEmail, welcomeEmail } from "../Middleware/Email.js";
import UserModel from "../Model/UserModel.js";
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'

// Register New User
export const registerUser = async (req, res) => {
    const { email, password, firstName, lastName } = req.body

    if (!email || !password || !firstName || !lastName) {
        res.status(400).json("Please Fillup All The Fields")
    }

    // if (!email.endsWith("@darshan.ac.in")) {
    //     return res.status(400).json({ message: "Only @darshan.ac.in emails are allowed" });
    // }

    if (!email.endsWith("gmail.com")) {
        return res.status(400).json({ message: "Please enter a valid email address `gmail.com`" });
    }

    const existingUser = await UserModel.findOne({ email })
    if (existingUser) {
        return res.status(400).json({ message: "User already exists Please Login" });
    }
    else {
        const salt = await bcrypt.genSalt(10)
        const hashedPassword = await bcrypt.hash(password, salt)
        const varificartionCode = Math.floor(100000 + Math.random() * 900000).toString()
        const otpExpireAt = Date.now() + 2 * 60 * 1000

        const newUser = new UserModel({ email, password: hashedPassword, firstName, lastName, varificartionCode, otpExpireAt })

        try {
            await newUser.save()
            sendVerificationEmail(email, varificartionCode)
            res.status(200).json({ message: "User registered successfully. Check your email for OTP.", newUser })
        } catch (error) {
            res.status(500).json({ message: "Error registering user", error: error.message })
        }
    }
}

// Verify OTP
export const verifyOTP = async (req, res) => {
    const { email, verificationCode } = req.body;

    try {
        const user = await UserModel.findOne({ email });
        if (!user || user.verificationCode !== verificationCode) {
            return res.status(400).json({ message: "Invalid OTP" });
        }

        user.isUserVerified = true;
        user.verificationCode = null;
        user.verificationExpires = null;
        await user.save();
        await welcomeEmail(user.email, user.firstName)

        res.status(200).json({ message: "Email verified successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error verifying OTP", error: error.message });
    }
};


// Login User
export const loginUser = async (req, res) => {
    const { email, password } = req.body;

    try {
        if (!process.env.JWT_SECRET) {
            throw createError(500, 'JWT_SECRET not defined in .env')
        }

        const user = await UserModel.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        if (!user.isUserVerified) {
            return res.status(400).json({ message: "Email not verified" });
        }

        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(400).json({ message: "Invalid credentials : Wrong password" });
        }

        const token = jwt.sign(
            { id: user._id, email: user.email },
            process.env.JWT_SECRET,
            { expiresIn: '1h' }
        )

        res.status(200).json({
            message: "Login successful",
            token,
            user: {
                _id: user._id,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName
            }
        })
    } catch (error) {
        res.status(500).json({ message: "Error logging in", error: error.message });
    }
};